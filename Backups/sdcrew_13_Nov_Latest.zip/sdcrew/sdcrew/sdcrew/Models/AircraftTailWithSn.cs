﻿using System;
using System.Collections.Generic;
using System.Text;

namespace sdcrew.Models
{
    public class AircraftTailWithSn
    {
        public string tailNumber { get; set; }
        public string serialNumber { get; set; }
    }
}
