﻿using Xamarin.Forms;

namespace sdcrew.Views.ViewHelpers.Renderers
{
    public class BorderlessEntry : Entry
    {

    }
}
