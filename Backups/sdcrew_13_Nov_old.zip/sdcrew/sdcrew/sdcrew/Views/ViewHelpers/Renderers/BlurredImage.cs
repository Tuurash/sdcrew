﻿using System;
using Xamarin.Forms;

namespace sdcrew.Views.ViewHelpers.Renderers
{
    public class BlurredImage : Image
    {
    }
}
