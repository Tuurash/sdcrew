﻿using System;
namespace sdcrew.Views.ViewHelpers.Styles
{
    public enum BorderDrawingStyle
    {
        Inside,
        Outside
    }
}
